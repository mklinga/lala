      </main>

      <footer id='footer'>
        <a type='email' href='mailto:puheenjohtaja@laitoslaulajat.fi'>
          <img src='assets/at.png' alt='email' />
        </a>
        <a href='tel:0400798487'>
          <img src='assets/phone.png' alt='puhelin' />
        </a>
        <a href='https://fi-fi.facebook.com/Laitoslaulajat/' target='_blank'>
          <img src='assets/face.png' alt='facebook' />
        </a>
      </footer>

    </div>
    <script src="assets/lala.js" type="text/javascript" charset="utf-8"></script>
  </body>
</html>
