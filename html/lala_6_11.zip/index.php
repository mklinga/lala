<?php include('head.php'); ?>

<div class='head'>
  <div class='stripe-container'>
    <img src='assets/top.jpg' />
  </div>
  <section class='header-text-block'>
    <h2>Musiikki koskettaa</h2>
    <p>
      Laulu virittää tunteet ja muistot. Me Laitoslaulajat ry:n laulajat tuomme musiikin iloa ikäihmisille kahdenkeskisissä kohtaamisissa.
      Me kohtaamme vanhuksia palvelutaloissa, kodeissa ja sairaaloissa. Esimerkiksi muistisairaiden on todettu hyötyvän musiikista, koska laulut pitävät sisällään paljon syviä muistoja.
    </p>
  </section>
</div>

<?php include('footer.php'); ?>
