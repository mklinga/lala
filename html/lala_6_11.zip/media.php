<?php include('head.php'); ?>


<section id='lala-mediassa' class='block'>
  <div>
    <h2>Hyvät tarinat koskettavat</h2>
    <p>
      Tässä poimintoja meistä tehdyistä lehtijutuista.
    </p>

    <div class='context-item'>
      <ul>
        <li><a href='/v2/assets/pdf/Hilkka_muisti.pdf'>Hilkka muisti laulun sanat (Somero-lehti 2.8.2016)</a></li>
        <li><a href='/v2/assets/pdf/Laitoslaulajat.pdf'>Laulu vain hänelle (Forssan lehti 21.1.2017)</a></li>
        <li><a href='/v2/assets/pdf/seura.pdf'>Laulettaisiinko vähän? (Seura 2/2015)</a></li>
        <li><a href='/v2/assets/pdf/Laulut_nostavat_muistot_pintaan.pdf'>Laulut nostavat muistot pintaan (Mielenterveys-lehti 4/2013)</a></li>
      </ul>
    </div>
  </div>
  <div>
    <img src='assets/mediassa.jpg' />
  </div>
</section>

<?php include('footer.php');
